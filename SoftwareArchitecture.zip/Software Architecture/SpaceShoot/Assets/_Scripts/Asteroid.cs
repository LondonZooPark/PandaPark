﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour {

    public float tumbleSpeed = 10.0f;
	// Use this for initialization
	void Start () {
        GetComponent<Rigidbody>().angularVelocity = Random.insideUnitSphere * tumbleSpeed;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
