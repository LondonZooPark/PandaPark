﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestoryByContact : MonoBehaviour {

    public GameObject explosion;
    public GameObject playerExplosion;
    public int scoreValue;
    private GameController gameController;
	// Use this for initialization
	void Start () {
        //print(gameObject.name);
        GameObject go = GameObject.FindWithTag("GameController");
        if (go != null)
        {
            gameController = go.GetComponent<GameController>();

        }
        else
        {
            Debug.Log("找不到游戏控制对象");
        }
        if(gameController == null)
        {
            Debug.Log("找不到游戏控制程序");
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Boundary")
        {
            //Destroy(gameObject);
            return;
        }

        //else { 
        Destroy(other.gameObject);
        Destroy(gameObject);
        Instantiate(explosion, transform.position, transform.rotation);
        gameController.AddScore(scoreValue);
        //Destroy(explosion);
        if (other.tag == "Player")
        {
            Instantiate(playerExplosion, other.transform.position, other.transform.rotation);
            gameController.GameOver();
            //Destroy(playerExplosion);
        }
        

        
        // }
    }


}
