﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {
    public GameObject hazard;
    public Vector3 spawnValue;
    public int hazardCount = 5;
    public float spawnWait = 1.0f;
    private Vector3 spawnPostion = Vector3.zero;
    private Quaternion spawnRoation;
    public int Score;
    public Text ScoreText;
    public Text gameOverText;
    public Text restartText;
    public Text usernameText;
    private bool gameoverState;
    public Transform RankPanel;
    public Transform GameOverPanel;

    public Text PlayerRank;
    public Text FirstRank;
    public Text SecondRank;
    public Text ThirdRank;
    //private Login login;
    string username;
    //public Scene scence;
    IEnumerator SpawnWaves()
    {
        while (true) {
            if (gameoverState)
            {
                break;
            }
            for (int i = 0; i <= hazardCount; ++i)
            {
                if (gameoverState)
                {
                    break;
                }
                spawnPostion.x = Random.Range(-spawnValue.x, spawnValue.x);
                spawnPostion.z = spawnValue.z;
                spawnRoation = Quaternion.identity;
                Instantiate(hazard, spawnPostion, spawnRoation);
                yield return new WaitForSeconds(spawnWait);

            }
            yield return new WaitForSeconds(spawnWait);
          
        }
        
    }
	void Start () {
        Score = 0;
        UpdateScore();
        gameoverState = false;
        gameOverText.text = "";
        restartText.text = "";
        StartCoroutine(SpawnWaves());
        username = Login.username;
        Debug.Log(username);
        usernameText.text = username;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.R)&&gameoverState == true)
        {
            SceneManager.LoadScene("Main");
        }
        if (Input.GetKeyDown(KeyCode.K) && gameoverState == true)
        {
            RankPanel.gameObject.SetActive(true);
            GameOverPanel.gameObject.SetActive(false);
             PlayerRank.text = "Player :"+username + "   Score :"+Score;
            GetScoreRank gsR = new GetScoreRank();
            string[] score = gsR.getScoreRank().Split(',');
            FirstRank.text = "First:"+score[0] + "   Score:"+score[1];
            SecondRank.text = "Second:" + score[2] + "   Score:" + score[3];
            ThirdRank.text = "Third:" + score[4] + "   Score:" + score[5];
}
    }


    public void AddScore(int ScoreValue){
        Score += ScoreValue;
        UpdateScore();
    }

    public void UpdateScore()
    {
        ScoreText.text = "Score :" + Score;
        

    }

    public void GameOver()
    {
        gameoverState = true;
        gameOverText.text = "Game Over Your Score :" + Score;
        restartText.text = "'R' to Restart Game ,'K' to Score Rank";
        UploadScore uploadscore = new UploadScore();
        uploadscore.upload(Score, username);
    }

}
