﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidMove : MonoBehaviour {

    public float AsteroidSpeed = -5.0f;
    // Use this for initialization
    void Start()
    {

        //GetComponent<Rigidbody>().velocity = blotspeed;

    }

    // Update is called once per frame
    void Update()
    {
        // float moveVertical = Input.GetAxis("Vertical");
        //float moveVertical;
        Vector3 movemoment = new Vector3(0.0f, 0.0f, AsteroidSpeed);
        GetComponent<Rigidbody>().velocity = movemoment;
    }
}
