﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Boundary
{
    public float xMin, xMax;
    public float zMin, zMax;
    public float yMin, yMax;
}
public class PlayerController : MonoBehaviour {

    private float speed = 10.0f;

    public GameObject shot;
    public GameObject bolt;
    public Transform shotspawn;
    public float fireRate = 0.5f;
    private float nextFire = 0.0f;
    //public BackGround background;
    public Boundary boundary;
    Rigidbody playerRigidbody;
	// Use this for initialization
	void Start () {
        this.playerRigidbody = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButton("Fire1") && Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            Instantiate(shot, shotspawn.position, shotspawn.rotation);
            GetComponent<AudioSource>().Play();
        }
        if (Input.GetKeyDown(KeyCode.Z) && Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            Instantiate(bolt, shotspawn.position, shotspawn.rotation);
            GetComponent<AudioSource>().Play();
        }
    }

     void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movemoment = new Vector3(moveHorizontal, 0.0f, moveVertical);
        //GetComponent<Rigidbody>().velocity = movemoment*speed;
        if(this.playerRigidbody != null)
        {
            playerRigidbody.velocity = movemoment * speed;
            playerRigidbody.position = new Vector3
            (
            Mathf.Clamp(playerRigidbody.position.x, boundary.xMin, boundary.xMax), 
            0.0f,
            Mathf.Clamp(playerRigidbody.position.z, boundary.yMin, boundary.yMax)
            );
        }

        
    }
}
