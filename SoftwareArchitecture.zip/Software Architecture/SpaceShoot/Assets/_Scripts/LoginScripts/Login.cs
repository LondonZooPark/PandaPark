﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.SceneManagement;
public class Login : MonoBehaviour {
    public Transform Loginpanel;
    public Transform Registpanel;
    public Transform Scorepanel;
    public Button button;
    public Button registbutton;
    public InputField usernameInputField;
    public InputField passwordInputField;
    public Text FirstRank;
    public Text SecondRank;
    public Text ThirdRank;
    public Image errorImage;
    public Image errorButton;
    const string ipAddress = "127.0.0.1";
    public static string username;
    IPAddress ip;
    Socket socket;
    //static IPAddress srvAddr = IPAddress.Parse(ipAddress); //服务器IP地址  
    //static IPEndPoint srvIpEnd = new IPEndPoint(srvAddr, 5099); //服务器地址  
    //EndPoint srvEnd = (EndPoint)srvIpEnd; //必须要经过这个类型转换,EndPoint是一个抽象类 
    // Use this for initialization
    void Start () {
        ip = IPAddress.Parse(ipAddress);
        //var Canvas = GameObject.Find("mainCanves");
        //Registpanel = Canvas.transform.FindChild("regist");
        //Loginpanel = Canvas.transform.FindChild("login");
        Registpanel.gameObject.SetActive(false);
        //srvAddr = IPAddress.Parse(ipAddress);
        //srvIpEnd = new IPEndPoint(srvAddr, 5099);
        //EndPoint srvEnd = (EndPoint)srvIpEnd;
        //socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        //SOCKET sockClient = socket(AF_INET, SOCK_STREAM, 0);

    }
	
	// Update is called once per frame
	void Update () {
		
	}



    public void onClickLogin()
    {
        byte[] recvBuf = new byte[1024];
        //byte[] recvBuftest = new byte[1024];
        socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        socket.Connect(new IPEndPoint(ip, 5099));
        socket.Send(Encoding.ASCII.GetBytes("1001:"+usernameInputField.text+"+"+passwordInputField.text));
        int resultlenth = socket.Receive(recvBuf);
        //int rest = socket.ReceiveFrom(recvBuftest, ref srvEnd);
        string recvResult = Encoding.ASCII.GetString(recvBuf,0, resultlenth);
        //string recvResulttest = System.Text.Encoding.ASCII.GetString(recvBuftest);
        Debug.Log(recvResult);
        //Debug.Log(recvResulttest);
        //string test = recvResult;
        //string scuucessRes = "true";
        //Debug.Log(string.Equals(test, "true"));
        //Debug.Log(string.Equals(recvResult, scuucessRes));
        if (string.Equals(recvResult, "true"))
        {
            username = usernameInputField.text;
            SceneManager.LoadScene("Main");
            
        }
        if (string.Equals(recvResult, "false"))
        {
            //UnityEditor.EditorUtility.DisplayDialog("登录失败","账号或密码错误","确认");
            errorImage.gameObject.SetActive(true);
        }
        socket.Close();
        //socket.Send(Encoding.ASCII.GetBytes(usernameInputField+","+passwordInputField));
    }

   
    public void onClickRegist()
    {
        Loginpanel.gameObject.SetActive(false);
        Registpanel.gameObject.SetActive(true);
    }
    public void onErrorButton()
    {
        errorImage.gameObject.SetActive(false);
        
    }
    public void onClickReturn()
    {
        Loginpanel.gameObject.SetActive(true);
        Scorepanel.gameObject.SetActive(false);
    }
    public void onClickScoreRank()
    {
        Loginpanel.gameObject.SetActive(false);
        Scorepanel.gameObject.SetActive(true);
        GetScoreRank gsR = new GetScoreRank();
        string[] score = gsR.getScoreRank().Split(',');
        FirstRank.text = "First:"+score[0] + "   Score:"+score[1];
        SecondRank.text = "Second:" + score[2] + "   Score:" + score[3];
        ThirdRank.text = "Third:" + score[4] + "   Score:" + score[5];
        //ThirdRank.text = "NIU BI";
    }
}
