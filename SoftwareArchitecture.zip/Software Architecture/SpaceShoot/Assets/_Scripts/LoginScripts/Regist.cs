﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Net;
using System.Net.Sockets;
using System.Text;

public class Regist : MonoBehaviour {
    public Transform Loginpanel;
    public Transform Registpanel;
    public Button Registbutton;
    public Button Returnbutton;
    public InputField usernameInputField;
    public InputField passwordInputField;
    const string ipAddress = "127.0.0.1";
    IPAddress ip;
    Socket socket;
    // Use this for initialization
    void Start () {
        ip = IPAddress.Parse(ipAddress);
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void onClickRegist()
    {
        byte[] recvBuf = new byte[1024];
        //byte[] recvBuftest = new byte[1024];
        socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        socket.Connect(new IPEndPoint(ip, 5099));
        socket.Send(Encoding.ASCII.GetBytes("1002:" + usernameInputField.text + "+" + passwordInputField.text));
        int resultlenth = socket.Receive(recvBuf);
        //int rest = socket.ReceiveFrom(recvBuftest, ref srvEnd);
        string recvResult = Encoding.ASCII.GetString(recvBuf, 0, resultlenth);
        //string recvResulttest = System.Text.Encoding.ASCII.GetString(recvBuftest);
        Debug.Log(recvResult);
        //Debug.Log(recvResulttest);
        //string test = recvResult;
        //string scuucessRes = "true";
        //Debug.Log(string.Equals(test, "true"));
        //Debug.Log(string.Equals(recvResult, scuucessRes));
        if (string.Equals(recvResult, "true"))
        {
            //UnityEditor.EditorUtility.DisplayDialog("注册成功", "注册成功,点击返回按钮返回登录界面", "确认");
            //yield return new WaitForSeconds(3);
            Loginpanel.gameObject.SetActive(false);
            Registpanel.gameObject.SetActive(true);
        }
        if (string.Equals(recvResult, "false"))
        {
            //UnityEditor.EditorUtility.DisplayDialog("注册失败", "注册失败", "确认");
        }
        socket.Close();
    }

    public void onClickReturn()
    {
        Loginpanel.gameObject.SetActive(true);
        Registpanel.gameObject.SetActive(false);
    }
}
