﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class BackGround : MonoBehaviour {

    public float xMin, xMax;
    public float zMin, zMax;

}
