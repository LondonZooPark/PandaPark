#pragma once  
#define WIN32_LEAN_AND_MEAN  // Exclude rarely-used stuff from Windows headers  
#include <stdio.h> 
#include <stdlib.h> 
#include <tchar.h>
#include <iostream>
#include <vector>
#include "sqloperator.h"
#include "Server.h"
#include <WinSock2.h>

//#include <stdafx.h> 
#import "c:\Users\lenovo\Documents\Visual Studio 2017\Projects\spaceshooterServer\sql\msado15.dll"  no_namespace rename("EOF", "EndOfFile")  
#pragma comment(lib, "ws2_32.lib")  

using namespace std;
int main() {
	/*
	//char *sqlCommand = "insert into userinfo values('admin','admin'); ";
	char *sqlCommand = "select * from userinfo; ";
	//_bstr_t strConnect = "DSN=sql2008;Database=spaceshooter;uid=sa;pwd=123;";
	_bstr_t strConnect = "Driver={sql server};server=127.0.0.1,1433;uid=sa;pwd=123;database=spaceshooter;";
	//��ʼ��COM��  
	::CoInitialize(NULL);
	//����һ��ָ��Connection�����ָ��m_pConnection  
	_ConnectionPtr m_pConnection(__uuidof(Connection));
	_RecordsetPtr pRst(__uuidof(Recordset));
	//����Connection����  
	if (FAILED(m_pConnection.CreateInstance(__uuidof(Connection))))
	{
		printf("����Connection����ʱ����\n");
	}

	try
	{
		//�������ݿ�  
		m_pConnection->Open(strConnect, "", "", adModeUnknown);
	}
	catch (_com_error e)
	{
		printf("�������ݿ�ʱ����\n");
	}
	
	pRst = m_pConnection->Execute(sqlCommand, NULL, 1);//ִ��SQL��� 
	if (!pRst->BOF) {
		pRst->MoveFirst();
	}
	else {
		cout << "Data is empty!" << endl;
	}


	vector<_bstr_t> column_name;
	for (int i = 0; i< pRst->Fields->GetCount(); i++)
	{
		cout << pRst->Fields->GetItem(_variant_t((long)i))->Name << " ";
		column_name.push_back(pRst->Fields->GetItem(_variant_t((long)i))->Name);
	}
	cout << endl;

	while (!pRst->EndOfFile)
	{
		vector<_bstr_t>::iterator iter = column_name.begin();
		for (iter; iter != column_name.end(); iter++)
		{
			if (pRst->GetCollect(*iter).vt != VT_NULL)
			{
				cout << (_bstr_t)pRst->GetCollect(*iter) << " ";
			}
			else
			{
				cout << "NULL" << endl;
			}
		}
		pRst->MoveNext();
		cout << endl;
	}
	m_pConnection->Close();
	//�ͷų���ռ�õ�COM ��Դ  
	::CoUninitialize();
	*/
	Sqloperator* sqlop = new Sqloperator();
	Server* server = new Server();
	string username;
	string password;
	_ConnectionPtr m_pConnection;
	char test[1024] = "1001:admin+Jack123213";
	vector<string> testStr;
	/*m_pConnection = sqlop->linkdatebase();
	cout << "enter your username" << endl;
	cin >> username;
	cout << "enter your password" << endl;
	cin >> password;
	*/
	/*
	if (sqlop->checkLogin("admin", "admin", m_pConnection) == true) {
		cout << "hello" << endl;
	}
	*/
	
	/*if (sqlop->checkLogin(username,password, m_pConnection) == true) {
		cout << "hello" << endl;
	}*/
	/*
	WSADATA wsaData;
	int port = 5099;

	char buf[] = "Server: hello, I am a server.....";

	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
	{
		printf("Failed to load Winsock");
		return 0;
	}

	//�������ڼ������׽���  
	SOCKET sockSrv = socket(AF_INET, SOCK_STREAM, 0);

	SOCKADDR_IN addrSrv;
	addrSrv.sin_family = AF_INET;
	addrSrv.sin_port = htons(port); //1024���ϵĶ˿ں�  
	addrSrv.sin_addr.S_un.S_addr = htonl(INADDR_ANY);

	int retVal = bind(sockSrv, (LPSOCKADDR)&addrSrv, sizeof(SOCKADDR_IN));
	if (retVal == SOCKET_ERROR) {
		printf("Failed bind:%d\n", WSAGetLastError());
		return 0;
	}

	if (listen(sockSrv, 10) == SOCKET_ERROR) {
		printf("Listen failed:%d", WSAGetLastError());
		return 0;
	}

	SOCKADDR_IN addrClient;
	int len = sizeof(SOCKADDR);

	while (1)
	{
		//�ȴ��ͻ�������    
		SOCKET sockConn = accept(sockSrv, (SOCKADDR *)&addrClient, &len);
		if (sockConn == SOCKET_ERROR) {
			printf("Accept failed:%d", WSAGetLastError());
			break;
		}

		printf("Accept client IP:[%s]\n", inet_ntoa(addrClient.sin_addr));

		//��������  
		int iSend = send(sockConn, buf, sizeof(buf), 0);
		if (iSend == SOCKET_ERROR) {
			printf("send failed");
			break;
		}

		char recvBuf[1024];
		//string recvMess;
		memset(recvBuf, 0, sizeof(recvBuf));
		//memset(recvMess, 0, sizeof(recvBuf));
		//      //��������  
		recv(sockConn, recvBuf, sizeof(recvBuf), 0);
		string resvMess(recvBuf);
		
		cout << "NIUBI"+resvMess << endl;

		printf("%s\n", recvBuf);

		closesocket(sockConn);
	}

	closesocket(sockSrv);
	WSACleanup();
	//system("pause");
	*/
	server->openServer();
	/*
	testStr = server->analysisMessage(test,0,sizeof(test));
	for (int i=0; i < testStr.size(); i++) {
		cout << testStr[i] << endl;
	}
	cout <<testStr.size() << endl;
	*/
	return 0;
}