#include"getScoreRank.h"
string getscore_rank::concrete_Method(vector<string> parsed_Message, Sqloperator *sqlop, _ConnectionPtr m_pConnection) {
	if ("2002" == parsed_Message[0]) {
		
		string scoreRank = sqlop->getScoreRank(parsed_Message[1], parsed_Message[2], m_pConnection);
			return scoreRank;
	}
}