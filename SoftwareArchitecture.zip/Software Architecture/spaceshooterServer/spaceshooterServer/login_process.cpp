#include"login_process.h"

string login_process::concrete_Method(vector<string> parsed_Message, Sqloperator *sqlop, _ConnectionPtr m_pConnection) {
	printf("hello test");
	//this->sqlop = new Sqloperator();
	if ("1001" == parsed_Message[0]) {
		if (sqlop->checkLogin(parsed_Message[1], parsed_Message[2], m_pConnection) == true) {
			cout << "hello" << endl;
			//char buf[] = "true";
			return "true";
		}
		else {
			//char buf[] = "false";
			return "false";
		}
	}
}
