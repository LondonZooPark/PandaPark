#pragma once
#ifndef LOGIN_PROCESS_H
#define LOGIN_PROCESS_H
#include "abstract_messageMethod.h"
class login_process 
{
public:
	string concrete_Method(vector<string> parsed_Message, Sqloperator *sqlop, _ConnectionPtr m_pConnection);

private:
	//Sqloperator *sqlop;
	//_ConnectionPtr m_pConnection;
};
#endif // !LOGIN_PROCESS_H