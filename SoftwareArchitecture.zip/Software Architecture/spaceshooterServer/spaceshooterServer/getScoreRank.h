#pragma once
#include "abstract_messageMethod.h"

#ifndef GETSCORERANK_H
#define GETSCORERANK_H
class getscore_rank
{
public:
	string concrete_Method(vector<string> parsed_Message, Sqloperator *sqlop, _ConnectionPtr m_pConnection);

private:
	//Sqloperator *sqlop;
	//_ConnectionPtr m_pConnection;

};
#endif // !GETSCORERANK_H
#pragma once
