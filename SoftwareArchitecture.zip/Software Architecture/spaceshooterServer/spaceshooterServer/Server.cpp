#include "Server.h"

void Server::openServer() {
	this->sqlop = new Sqloperator();
	this->m_pConnection = sqlop->linkdatebase();
	char buf[] = "Server: hello, I am a server.....";

	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
	{
		printf("Failed to load Winsock");
		//return 0;
	}

	//�������ڼ������׽���  
	SOCKET sockSrv = socket(AF_INET, SOCK_STREAM, 0);

	SOCKADDR_IN addrSrv;
	addrSrv.sin_family = AF_INET;
	addrSrv.sin_port = htons(port); //1024���ϵĶ˿ں�  
	addrSrv.sin_addr.S_un.S_addr = htonl(INADDR_ANY);

	int retVal = bind(sockSrv, (LPSOCKADDR)&addrSrv, sizeof(SOCKADDR_IN));
	if (retVal == SOCKET_ERROR) {
		printf("Failed bind:%d\n", WSAGetLastError());
		//return 0;
	}

	if (listen(sockSrv, 10) == SOCKET_ERROR) {
		printf("Listen failed:%d", WSAGetLastError());
		//return 0;
	}

	SOCKADDR_IN addrClient;
	int len = sizeof(SOCKADDR);

	while (1)
	{
		//�ȴ��ͻ�������    
		//SOCKET sockConn = accept(sockSrv, (SOCKADDR *)&addrClient, &len);
		this->sockConn = accept(sockSrv, (SOCKADDR *)&addrClient, &len);
		if (sockConn == SOCKET_ERROR) {
			printf("Accept failed:%d", WSAGetLastError());
			break;
		}

		printf("Accept client IP:[%s]\n", inet_ntoa(addrClient.sin_addr));
		messProcess->process(this->sockConn,this->sqlop,this->m_pConnection);
		//recvMessage();
		/*
		//��������  
		int iSend = send(sockConn, buf, sizeof(buf), 0);
		if (iSend == SOCKET_ERROR) {
			printf("send failed");
			break;
		}
		
		char recvBuf[1024];
		//string recvMess;
		memset(recvBuf, 0, sizeof(recvBuf));
		//memset(recvMess, 0, sizeof(recvBuf));
		//      //��������  
		recv(sockConn, recvBuf, sizeof(recvBuf), 0);
		string resvMess(recvBuf);
		
		cout <<  resvMess << endl;

		printf("%s\n", recvBuf);
		*/
		closesocket(sockConn);
	}

	closesocket(sockSrv);
	WSACleanup();
	//system("pause");
}

void Server::recvMessage() {
	char recvBuf[1024];
	vector<string> parsed_Message;
	//string recvMess;
	memset(recvBuf, 0, sizeof(recvBuf));
	//memset(recvMess, 0, sizeof(recvBuf));
	//      //��������  
	recv(sockConn, recvBuf, sizeof(recvBuf), 0);
	string resvMess(recvBuf);
	//if(absMessProcess->process(recvBuf);
	/*
	cout << resvMess << endl;

	printf("%s\n", recvBuf);

	parsed_Message = analysisMessage(recvBuf, 0, sizeof(recvBuf));
	if ("1001" == parsed_Message[0]) {
		if (sqlop->checkLogin(parsed_Message[1], parsed_Message[2], this->m_pConnection) == true) {
			cout << "hello" << endl;
			char buf[] = "true";
			sendMessage(buf);
		}
		else {
			char buf[] = "false";
			sendMessage(buf);
		}
	}
	*/
}

void Server::sendMessage(char buf[]) {
	//string buf = ""
	SOCKADDR_IN addrClient;
	int len = sizeof(SOCKADDR);
		//int iSend = send(sockConn, buf, sizeof(buf), 0);
		sendto(this->sockConn, buf, strlen(buf), 0, (sockaddr*)&addrClient, len);

}

vector<string> Server::analysisMessage(char message[], int M_begin, int M_end) {
	vector<string> parsed_Message;
	//string M_head;
	char head[1024];
	for (int i = 0; i<4; i++) {
		head[i] = message[i];
		if (i == 3) {
			head[i + 1] = '\0';
		}
	}
	cout << message << endl;
	cout << head <<endl;
	int M_head = atoi(head);
	cout << M_head << endl;
	if (1001 == M_head) {
		int Delimiter_Location;
		for (int i = 4; i <= M_end; ++i) {
			if ('+' == message[i]) {
				Delimiter_Location = i;
			}
		}
		char username[1024];
		char password[1024];
		for (int i = 5, n = 0; i < Delimiter_Location; ++i) {
				username[n] = message[i];
				if (i == Delimiter_Location-1) {
					username[n + 1] = '\0';
				}
				++n;
		}
		for (int i = Delimiter_Location+1,n = 0; i <= M_end; ++i) {
				password[n] = message[i];
				if (i == M_end-1) {
					password[n + 1] = '\0';
				}
				++n;
		}
		string headStr(head);
		string usernameStr(username);
		string passwordStr(password);
		parsed_Message.push_back(headStr);
		parsed_Message.push_back(usernameStr);
		parsed_Message.push_back(passwordStr);

	}
	return parsed_Message;
}