#include "sqloperator.h"

Sqloperator::Sqloperator()
{
	
	::CoInitialize(NULL);
}
_ConnectionPtr Sqloperator::linkdatebase() {
	//this->m_pConnection(__uuidof(Connection));
	//pRst(__uuidof(Recordset));
	_ConnectionPtr m_pConnection(__uuidof(Connection));
	_RecordsetPtr pRst(__uuidof(Recordset));
	if (FAILED(m_pConnection.CreateInstance(__uuidof(Connection))))
	{
		printf("����Connection����ʱ����\n");
	}

	try
	{
		//�������ݿ�  
		m_pConnection->Open(strConnect, "", "", adModeUnknown);
	}
	catch (_com_error e)
	{
		printf("�������ݿ�ʱ����\n");
	}
	return m_pConnection;
}
bool Sqloperator::checkLogin(string username,string password, _ConnectionPtr m_pConnection) {
	//char* loginSQLsetence = 
	_RecordsetPtr pRst(__uuidof(Recordset));
	string loginSQLsetence = "select * from userinfo where username = '" + username + "' and password = '" + password + "'";
	//char* logincom = loginSQLsetence.c
	pRst = m_pConnection->Execute(_bstr_t(loginSQLsetence.c_str()), NULL, 1);
	
	if (!pRst->BOF) {

		vector<_bstr_t> column_name;
		for (int i = 0; i< pRst->Fields->GetCount(); i++)
		{
			cout << pRst->Fields->GetItem(_variant_t((long)i))->Name << " ";
			column_name.push_back(pRst->Fields->GetItem(_variant_t((long)i))->Name);
		}
		cout << endl;
		vector<_bstr_t>::iterator iter = column_name.begin();
		for (iter; iter != column_name.end(); iter++)
		{
			if (pRst->GetCollect(*iter).vt != VT_NULL)
			{
				cout << (_bstr_t)pRst->GetCollect(*iter) << " ";
			}
			else
			{
				cout << "NULL" << endl;
			}
		}
		cout << endl;
		return true;
	}
	else {
		cout << "LoginFiald!" << endl;
		return false;
	}
		//"select * from userinfo where username = '" + username + "' and password = '' ";
}

bool Sqloperator::registUser(string username, string password, _ConnectionPtr m_pConnection) {
	//char *sqlCommand = "insert into userinfo values('admin','admin')";
	string loginSQLsetence = "insert into userinfo values( '" + username + "', '" + password + "')";
	_RecordsetPtr pRst(__uuidof(Recordset));
	pRst = m_pConnection->Execute(_bstr_t(loginSQLsetence.c_str()), NULL, 1);
	//if (!pRst->BOF) {
		cout << "regist success" << endl;
		return true;
	//}
	//else {
	//	return false;
	//}
	//return true;
}

bool Sqloperator::uploadScore(string username, string score, _ConnectionPtr m_pConnection) {
	string loginSQLsetence = "insert into scoretable values( '" + username + "', '" + score + "')";
	_RecordsetPtr pRst(__uuidof(Recordset));
	pRst = m_pConnection->Execute(_bstr_t(loginSQLsetence.c_str()), NULL, 1);
	//if (!pRst->BOF) {
	cout << "score uploadsuccess" << endl;
	return true;
}

string Sqloperator::getScoreRank(string username, string score, _ConnectionPtr m_pConnection) {
	_RecordsetPtr pRst(__uuidof(Recordset));
	string scoreRank;
	string SQLsetence = "select top 3 * from scoretable order by score desc";
	//char* logincom = loginSQLsetence.c
	pRst = m_pConnection->Execute(_bstr_t(SQLsetence.c_str()), NULL, 1);
	if (!pRst->BOF) {
		pRst->MoveFirst();
	}
	else {
		cout << "Data is empty!" << endl;
	}
		vector<_bstr_t> column_name;
		for (int i = 0; i< pRst->Fields->GetCount(); i++)
		{
			cout << pRst->Fields->GetItem(_variant_t((long)i))->Name << " ";
			column_name.push_back(pRst->Fields->GetItem(_variant_t((long)i))->Name);
		}
		cout << endl;
		while (!pRst->EndOfFile)
		{
			vector<_bstr_t>::iterator iter = column_name.begin();
			for (iter; iter != column_name.end(); iter++)
			{
				if (pRst->GetCollect(*iter).vt != VT_NULL)
				{
					cout << (_bstr_t)pRst->GetCollect(*iter) << " ";
					scoreRank += (_bstr_t)pRst->GetCollect(*iter)+",";
				}
				else
				{
					cout << "NULL" << endl;
				}
			}
			//scoreRank += ",";
			pRst->MoveNext();
			cout << endl;
		}
		cout << scoreRank << endl;
		//return scoreRank;

	return scoreRank;
}