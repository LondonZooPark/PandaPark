#include "message_process.h"
/*
vector<string>analysis_Message(char message[], int M_begin, int M_end);
void process();
virtual void concrete_Method();

*/
vector<string> MessageProcess::analysis_Message(char message[], int M_begin, int M_end) {
	vector<string> parsed_Message;
	//string M_head;
	char head[1024];
	for (int i = 0; i<4; i++) {
		head[i] = message[i];
		if (i == 3) {
			head[i + 1] = '\0';
		}
	}
	cout << message << endl;
	cout << head << endl;
	int M_head = atoi(head);
	cout << M_head << endl;
	
		int Delimiter_Location;
		for (int i = 4; i <= M_end; ++i) {
			if ('+' == message[i]) {
				Delimiter_Location = i;
			}
		}
		char username[1024];
		char setence[1024];
		for (int i = 5, n = 0; i < Delimiter_Location; ++i) {
			username[n] = message[i];
			if (i == Delimiter_Location - 1) {
				username[n + 1] = '\0';
			}
			++n;
		}
		for (int i = Delimiter_Location + 1, n = 0; i <= M_end; ++i) {
			setence[n] = message[i];
			if (i == M_end - 1) {
				setence[n + 1] = '\0';
			}
			++n;
		}
		string headStr(head);
		string usernameStr(username);
		string setenceStr(setence);
		parsed_Message.push_back(headStr);
		parsed_Message.push_back(usernameStr);
		parsed_Message.push_back(setenceStr);

	return parsed_Message;
}
string MessageProcess::recvMessage(SOCKET sockConn) {
	char recvBuf[1024];
	vector<string> parsed_Message;
	//string recvMess;
	memset(recvBuf, 0, sizeof(recvBuf));
	//memset(recvMess, 0, sizeof(recvBuf));
	//      //��������  
	recv(sockConn, recvBuf, sizeof(recvBuf), 0);
	string resvMess(recvBuf);
	//if(absMessProcess->process(recvBuf);
	
	cout << resvMess << endl;

	printf("%s\n", recvBuf);

	string rcvStr(recvBuf);
	return rcvStr;

	
}
void MessageProcess::sendMessage(char buf[], SOCKET sockConn) {
	//string buf = ""
	string testbuf;
	//strcpy(buf, testbuf.c_str());
	SOCKADDR_IN addrClient;
	int len = sizeof(SOCKADDR);
	//int iSend = send(sockConn, buf, sizeof(buf), 0);
	sendto(sockConn, buf, strlen(buf), 0, (sockaddr*)&addrClient, len);
	//sendto(sockConn, testbuf, strlen(buf), 0, (sockaddr*)&addrClient, len);

}
void MessageProcess::process(SOCKET sockConn, Sqloperator *sqlop, _ConnectionPtr m_pConnection) {
	vector<string> parsed_Message; 
	//this->sqlop = sqlopform_out;
	//this->m_pConnection = m_pConnectionform_out;
	char returnBuf[1024];
	char message[1024];
	string returnStr;
	string recStr;
	recStr = recvMessage(sockConn);
	strcpy(message, recStr.c_str());
	parsed_Message = analysis_Message(message, 0, sizeof(message));
	//cout << "hello" << endl;
	if ("1001" == parsed_Message[0]) {
		login_process *lop = new login_process();
		returnStr = lop->concrete_Method(parsed_Message, sqlop, m_pConnection);
		//if (sqlop->checkLogin(parsed_Message[1], parsed_Message[2],m_pConnection) == true) {
			//cout << "hello" << endl;
			//char buf[] = "true";
			//returnStr == "true";
		//}
		//else {
			//char buf[] = "false";
			//returnStr = "false";
		//}
	}
	if ("1002" == parsed_Message[0]) {
		regist_process *reg_p = new regist_process();
		returnStr = reg_p->concrete_Method(parsed_Message,sqlop, m_pConnection);
	}
	if ("2001" == parsed_Message[0]) {
		uploadScore_process *upS_p = new uploadScore_process();
		returnStr = upS_p->concrete_Method(parsed_Message, sqlop, m_pConnection);
	}
	if ("2002" == parsed_Message[0]) {
		getscore_rank *gs_p = new getscore_rank();
		returnStr = gs_p->concrete_Method(parsed_Message, sqlop, m_pConnection);
	}
	sendMessage(strcpy(returnBuf,returnStr.c_str()),sockConn);
	
}

