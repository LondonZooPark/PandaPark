#include"regist_process.h"

string regist_process::concrete_Method(vector<string> parsed_Message, Sqloperator *sqlop, _ConnectionPtr m_pConnection) {
	if ("1002" == parsed_Message[0]) {
		if (sqlop->registUser(parsed_Message[1], parsed_Message[2], m_pConnection) == true) {
			cout << "regist success" << endl;
			//char buf[] = "true";
			return "true";
		}
		else {
			//char buf[] = "false";
			return "false";
		}
	}
}