#pragma once
#include "abstract_messageMethod.h"

#ifndef UPLOADSCORE_PROCESS_H
#define UPLOADSCORE_PROCESS_H
class uploadScore_process
{
public:
	string concrete_Method(vector<string> parsed_Message, Sqloperator *sqlop, _ConnectionPtr m_pConnection);

private:
	//Sqloperator *sqlop;
	//_ConnectionPtr m_pConnection;

};
#endif // !UPLOADSCORE_PROCESS_H
