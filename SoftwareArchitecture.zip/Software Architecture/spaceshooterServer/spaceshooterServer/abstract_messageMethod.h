#include<vector>
#include<iostream>
#include<string>
#include"sqloperator.h"
#ifndef ABSTRACT_MESSAGEMETHOD_H
#define ABSTRACT_MESSAGEMETHOD_H

using namespace std;
class Abs_messageMethod {
public:
	virtual string concrete_Method(vector<string> parsed_Message);
protected:
	Sqloperator *sqlop;
	_ConnectionPtr m_pConnection;
};

#endif // !ABSTRACT_MESSAGEMETHOD_H