#pragma once
#include <string>
#include <stdio.h>  
#include <tchar.h>
#include <iostream>
#include <vector>
#ifndef SQLOPERATOR_H
#define SQLOPERATOR_H
using namespace std;
#import "c:\Users\lenovo\Documents\Visual Studio 2017\Projects\spaceshooterServer\sql\msado15.dll"  no_namespace rename("EOF", "EndOfFile")  
class Sqloperator
{
private:
	//_ConnectionPtr m_pConnection;
	//_RecordsetPtr pRst;
	const _bstr_t strConnect = "Driver={sql server};server=127.0.0.1,1433;uid=sa;pwd=123;database=spaceshooter;";
public:
	Sqloperator();//���캯��
	//Sqloperator(_ConnectionPtr m_pConnection, _RecordsetPtr pRst);
	//void linkdatebase();
	_ConnectionPtr linkdatebase();
	bool checkLogin(string username,string password, _ConnectionPtr m_pConnection);
	bool registUser(string username, string password, _ConnectionPtr m_pConnection);
	bool uploadScore(string username, string password, _ConnectionPtr m_pConnection);
	string getScoreRank(string username, string score, _ConnectionPtr m_pConnection);
};

#endif