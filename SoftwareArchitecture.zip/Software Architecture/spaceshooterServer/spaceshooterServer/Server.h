#pragma once
#include <WinSock2.h>
#include <stdio.h> 
#include <stdlib.h> 
#include <iostream>
#include <string>
#include <vector>
#include "sqloperator.h"
#include "message_process.h"
#pragma comment(lib, "ws2_32.lib")  
#ifndef SERVER_H
#define SERVER_H

using namespace std;

class Server 
{
	private :

		const int port = 5099;
		WSADATA wsaData;
		SOCKET sockConn;
		Sqloperator *sqlop;
		_ConnectionPtr m_pConnection;
		MessageProcess *messProcess;
	public:
		//string analysicMessageHead(char message[], int M_begin, int M_end);
		vector<string> analysisMessage(char message[],int M_begin, int M_end);
		void openServer();
		void recvMessage();
		void sendMessage(char buf[]);

};
#endif
