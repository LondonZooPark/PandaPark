#pragma once
#include "abstract_messageMethod.h"

#ifndef REGIST_PROCESS_H
#define REGIST_PROCESS_H
class regist_process 
{
public:
	string concrete_Method(vector<string> parsed_Message, Sqloperator *sqlop, _ConnectionPtr m_pConnection);

private:
	//Sqloperator *sqlop;
	//_ConnectionPtr m_pConnection;

};
#endif // !REGIST_PROCESS_H