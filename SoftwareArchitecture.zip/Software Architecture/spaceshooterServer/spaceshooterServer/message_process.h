#include<vector>
#include<iostream>
#include<string>
#include"sqloperator.h"
//#include"abstract_messageMethod.h"
#include"login_process.h"
#include"regist_process.h"
#include"uploadScore_process.h"
#include"getScoreRank.h"
#ifndef MESSAGE_PROCESS_H
#define MESSAGE_PROCESS_H

using namespace std;
class MessageProcess{
	public:
		vector<string>analysis_Message(char message[], int M_begin, int M_end);
		void process(SOCKET sockConn, Sqloperator *sqlop, _ConnectionPtr m_pConnection);
		string recvMessage(SOCKET sockConn);
		void sendMessage(char buf[], SOCKET sockConn);
		//virtual  concrete_Method(vector<string> parsed_Message);
	protected:
		//Sqloperator *sqlop;
		//_ConnectionPtr m_pConnection;
	private:
		//Abs_messageMethod *abs_meH;
		//login_process *lop;

};


#endif // !MESSAGE_PROCESS_H


